C:\Users\Balachandar.S\.m2\repository\org\projectlombok\lombok\1.18.30

============================================================= Links

https://www.baeldung.com/spring-tls-setup

keytool -genkeypair -alias baeldung -keyalg RSA -keysize 4096 -validity 3650 -dname "CN=localhost" -keypass changeit -keystore keystore.p12 -storeType PKCS12 -storepass changeit

keytool -list -v -keystore keystore.p12

==========================================================JWE

https://medium.com/@parsag67/securing-your-spring-boot-with-jwe-a-guide-to-implementing-jwt-encryption-for-user-authentication-173fcc4fd970

https://medium.com/@messias.lsn/spring-boot-3-oauth-2-0-jwe-48042db9f814
https://github.com/Messias-Dev/spring-oauth

https://learnersbucket.com/examples/java/load-public-and-private-keys-in-java-spring-boot/

https://chanakambkarunarathna.medium.com/encrypt-and-decrypt-sensitive-data-with-jwe-70421722f7e5

https://learnersbucket.com/examples/java/how-to-do-jwe-encryption-in-java/#google_vignette

https://stackoverflow.com/questions/72302595/spring-boot-how-to-load-a-keystore-resource-file-either-from-the-classpath-or-f

https://www.sslshopper.com/article-how-to-create-a-self-signed-certificate-using-java-keytool.html

https://www.sslshopper.com/article-most-common-java-keytool-keystore-commands.html