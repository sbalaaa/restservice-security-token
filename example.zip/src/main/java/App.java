import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.text.ParseException;
import java.util.Date;
import java.util.UUID;

import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.EncryptedJWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;


/**
 * Example code for decrypting a JWE
 *
 */
public class App {
	public static void main(String[] args) {
		// Generate a key pair
		App app = new App();
		// Build a simulated JWT - note this is just a subset of claims that may be sent, refer to the API specification for details on the claims
		String confirmationNumber = UUID.randomUUID().toString();
		JWTClaimsSet claimsSet = new JWTClaimsSet.Builder().subject(confirmationNumber)
				.expirationTime(new Date(System.currentTimeMillis() * 600000l))
				.claim("AccountIdentifier", "987654321")
				.claim("AccountName", "JANE DOE")
				.claim("AccountNumber", "9999999999")
				.claim("AccountType", "checking")
				.claim("AdvanceAmount", 500)
				.claim("ConfirmationNumber", 1670889315893L)
				.claim("EffectiveDate", "2022-12-13")
				.claim("LoanIdentifier", "0001234567")
				.claim("LoginUserName", "u000034561")
				.claim("PortfolioIdentifier", "040")
				.claim("Topic", "ELOC/DrawAdded")
				.claim("VerificationHoldIndicator", false)
				.claim("LoginAccountAliasName", "janedoe1234")
				.claim("VerificationHoldIndicator", false)
				.claim("RoutingTransitNumber", "123456789")
				.build();
		try {
			KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
			kpg.initialize(2048);
			KeyPair kp = kpg.generateKeyPair();
			RSAPublicKey publicKey = (RSAPublicKey) kp.getPublic();
			RSAPrivateKey privateKey = (RSAPrivateKey) kp.getPrivate();
			// use the private key to sign with and the public key to encrypt 
			String jweString = app.createJWE(claimsSet, privateKey, publicKey);
			System.out.println("Encrypted JWT String: " + jweString + "\n");
			EncryptedJWT decryptedJwt = app.decrypt(jweString, privateKey);
			System.out.println("Encrypted JWT Header: " + decryptedJwt.getHeader().toString() + "\n");
			SignedJWT signedJwt = decryptedJwt.getPayload().toSignedJWT();
			System.out.println("Decrypted JWS Header: " + signedJwt.getHeader().toString() + "\n");
			System.out.println("Decrypted JWT Claims: " + signedJwt.getJWTClaimsSet() + "\n");
			app.verifySignature(signedJwt, publicKey);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void verifySignature(SignedJWT signedJwt, RSAPublicKey publicKey) throws JOSEException {
		System.out.println("Verifying signature...");
		JWSVerifier verifier = new RSASSAVerifier((RSAPublicKey) publicKey);
		if (signedJwt.verify(verifier)) {
			System.out.println(" -- Successfully verified signature.");
		} else {
			System.out.println(" -- Signature could not be verified.");
		}
	}

	String createJWE(JWTClaimsSet claimsSet, Key signingKey, RSAPublicKey rsaPublicKey) throws JOSEException {
		SignedJWT signedJWT = createJWS(claimsSet, signingKey);
		JWEAlgorithm jweAlgorithm = JWEAlgorithm.RSA_OAEP_256;
		EncryptionMethod encryptionMethod = EncryptionMethod.A128CBC_HS256;
		JWEHeader.Builder headerBuilder = new JWEHeader.Builder(jweAlgorithm, encryptionMethod).keyID("12345");
		// Create an encrypted JWT object
		Payload payload = new Payload(signedJWT);
		JWEObject jweObject = new JWEObject(headerBuilder.build(), payload);
		// Create an RSAEncrypter with the specified public RSA key
		RSAEncrypter encrypter = new RSAEncrypter(rsaPublicKey);
		// Do the encryption
		jweObject.encrypt(encrypter);
		return jweObject.serialize();
	}
	
	SignedJWT createJWS(JWTClaimsSet claimsSet, Key signingKey) throws JOSEException  {
		JWSSigner signer = new RSASSASigner((PrivateKey) signingKey);
		SignedJWT signedJWT = new SignedJWT(new JWSHeader.Builder(JWSAlgorithm.RS256).keyID("54321").build(), claimsSet);
		// Compute the RSA signature
		signedJWT.sign(signer);
		return signedJWT;
	}

	EncryptedJWT decrypt(String jweString, RSAPrivateKey privateKey) throws ParseException, JOSEException {
		EncryptedJWT decryptedJwt = EncryptedJWT.parse(jweString);
		RSADecrypter decrypter = new RSADecrypter(privateKey);
		decryptedJwt.decrypt(decrypter);
		return decryptedJwt;
	}
}
